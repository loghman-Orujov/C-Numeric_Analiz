#include<stdio.h>
#include<math.h>
#define N 20
float fakt(int n){
	int i,carp=1;
	for(i=1;i<=n;i++)
	carp=carp*i;
	
	return carp;
}


float comp(int m, int n){

	float hesap;
	

	hesap=fakt(m)/(fakt(n)*fakt(m-n));
	return hesap;
}

float newfonk(int mat[][20],int n,float x){
	int k=1,i=0,j;
	float s,top=0;
    s=(x-mat[0][0])/(mat[1][0]-mat[0][0]);
	
		for(j=2;j<n;j++){
		top= top+ (comp(s,k))*mat[0][j];
		k++;
		}
	return top+mat[0][1];
}

float fonksiyon (float a[N], float b[N], int n, float x){
	int i;
	float function=0.0;
	for(i=0;i<n;i++){
	
		function= function + a[i] * pow(x,b[i]);
	}
	return function;
	
}

float turev(float a[N], float b[N], int n, float x){
	int i;
	float turrev=0.0;
	for(i=0;i<n;i++){
		if(b[i]!=0){
		turrev=turrev + a[i]*b[i]*pow(x,b[i]-1);
	}

	}
	return turrev;
}
float fonkx(float A[N][20] ,float C[N][1], float x00[N], int n){
	float sonuc;
	int i,j;
	sonuc=C[0][1];
	for(i=1;i<n;i++){
		sonuc=sonuc-(A[0][i]*x00[i]);
	}
	sonuc=sonuc/A[0][0];
	return sonuc;
}
float fonky(float A[N][20] ,float C[N][1], float x00[N], int n){

	float sonuc;
	int i,j;
	sonuc=C[1][1];
	for(i=0;i<n;i++){
		if(i!=1)
		sonuc=sonuc-(A[1][i]*x00[i]);
	}
	sonuc=sonuc/A[1][1];
	return sonuc;
}

float fonkz(float A[N][20] ,float C[N][1], float x00[N], int n){
	float sonuc;
	int i,j;
	sonuc=C[2][1];
	for(i=0;i<n;i++){
		if(i!=2)
		sonuc=sonuc-(A[2][i]*x00[i]);
	}
	sonuc=sonuc/A[2][2];
	return sonuc;
}
float fonkk(float A[N][20] ,float C[N][1], float x00[N], int n){
	float sonuc;
	int i,j;
	sonuc=C[3][1];
	for(i=0;i<n-1;i++){
		sonuc=sonuc-(A[3][i]*x00[i]);
	}
	sonuc=sonuc/A[3][3];
	return sonuc;
}

int main(){
	int islem;
	float start,end,ara,orta,hata,kok,MAX,MAX2=1.0,x,x0;
	int iterasyon=0;
	float a[N], b[N],c[N];
	int i,j,t,xx,sayi,kk ,n;
	float d,k,tmp,h,h_yedek,alan=0.0,sonuc;
	float aa[N][N];
	float bb[N][N];
	float cc[N][N];
	float C[N][1];
	float A[N][N];
	float x00[N];
	int mat[N][20];
	printf("Bisection yontemi: 0\nRegula-Falsi yontemi: 1\nNewton-Rapshon yontemi: 2\nN*N'lik bir matrisin tersi: 3\nGauss eliminasyon yontemi: 4\nGauss-Seidel yontemi: 5\nSayisal Turev: 6\nSimpson yontemi: 7\nTrapez yontemi: 8\ndegisken donusumsuz Gregory-Newton enterpolasyonu: 9");
	printf("\nyapmak istediginiz islem numarasini giriniz:");
	scanf("%d",&islem);
	switch(islem){
		
		case 0:
			printf("\n\n\t\t\t\t\tBISECTION YONTEMI\n");
			
	            printf("kokun bulundugu araligi giriniz: [a,b]\n");
	            printf("baslangic degeri: ");
	            scanf("%f",&start);
	            printf("bitis degeri: ");
	            scanf("%f",&end);
	            printf("hata payini giriniz: ");
	            scanf("%f",&hata);
	            printf("polinom sayisini giriniz:");
	            scanf("%d",&n);
	            for(i=0;i<n;i++){
		           printf("x_coef * x ^ x_exp:\n");
		           printf("x's cofactor (x_coef):");
		           scanf("%4f",&a[i]);
		           printf("x's exponent (x_exp):");
		           scanf("%4f",&b[i]);
		           printf("add: %4f * x ^ %4f\n",a[i],b[i]);
	            }
	
	            MAX=(end-start)/pow(2,iterasyon);
	            if(fonksiyon(a, b, n, start)*fonksiyon(a, b, n, end)<0){
		           printf("\n start\t\t mid\t\t end\t\t f(start) \t f(mid) \t f(end) \t \t  iterasyon\n");
		           while(iterasyon<100&&MAX>hata){
		 	            orta=(start+end)/2;
			            printf("\n %f\t %f\t %f\t",start,orta,end);
			            printf("%f\t %f\t %f\t",fonksiyon(a, b, n, start),fonksiyon(a, b, n, orta),fonksiyon(a, b, n, end));
			            if(fonksiyon(a, b, n, orta)*fonksiyon(a, b, n, start)<0){
			                end=orta;
			                iterasyon++;
			                printf("\t %d",iterasyon);
			                MAX=(end-start)/pow(2,iterasyon);
		                }
		                else{
			                start=orta;
			                iterasyon++;
			                printf("\t %d",iterasyon);
			                MAX=(end-start)/pow(2,iterasyon);
		                }//end else
			
	               }//end while	
	           	}//end if
		        else{
			        printf("kok bulunamadi");
		        }
	
	            printf("\n sonuc:%f",orta);
		
			break;
		case 1:
			printf("\n\n\t\t\t\t\tREGULA-FALSI YONTEMI\n"); 
			
		        printf("kokun bulundugu araligi giriniz: [a,b]\n");
	            printf("baslangic degeri: ");
	            scanf("%f",&start);
	            printf("bitis degeri: ");
	            scanf("%f",&end);
	            printf("hata payini giriniz: ");
	            scanf("%4f",&hata);
	            printf("polinom sayisini giriniz:");
	            scanf("%d",&n);
	            for(i=0;i<n;i++){
		           printf("x_coef * x ^ x_exp:\n");
		           printf("x's cofactor (x_coef):");
		           scanf("%4f",&a[i]);
		           printf("x's exponent (x_exp):");
		           scanf("%4f",&b[i]);
		           printf("add: %4f * x ^ %4f\n",a[i],b[i]);
	            }
	 	        MAX=(end-start)/pow(2,iterasyon);
	            if(fonksiyon(a, b, n, start)*fonksiyon(a, b, n, end)<0){
			        printf("\n start\t\t point\t\t end\t\t f(start) \t f(point) \t f(end) \t \t  iterasyon\n");
		
		            while(iterasyon<100&&MAX>hata){
		        	    kok=(start*fonksiyon(a, b, n, end)-end*fonksiyon(a, b, n, start))/(fonksiyon(a, b, n, end)-fonksiyon(a, b, n, start));
			            printf("\n %f\t %f\t %f\t",start,kok,end);
			            printf("%f\t %f\t %f\t",fonksiyon(a, b, n, start),fonksiyon(a, b, n, kok),fonksiyon(a, b, n, end));
			            if(fonksiyon(a, b, n, kok)*fonksiyon(a, b, n, start)<0){
			                end=kok;
			                iterasyon++;
			                printf("\t %d",iterasyon);
			                MAX=(end-start)/pow(2,iterasyon);
		                }
		                else{
			                start=kok;
			                iterasyon++;
			                printf("\t %d",iterasyon);
			                MAX=(end-start)/pow(2,iterasyon);
		                }//end else
			
		            }//end while
		
		        }//end if
		        else{
			        printf("kok bulunamadi");
		        }
	
			
		        printf("\n sonuc:%f",kok);
	
				break;
			
		case 2:
			printf("\n\n\t\t\t\t\tNEWTON-RAPSHON YONTEMI\n");
			
			    printf("baslangic degerini giriniz:");
                scanf("%f",&x0);
                printf("hata miktarini giriniz:");
                scanf("%f",&hata);
	            printf("polinom sayisini giriniz:");
	            scanf("%d",&n);
	            for(i=0;i<n;i++){
		            printf("x_coef * x ^ x_exp:\n");
	            	printf("x's cofactor (x_coef):");
		            scanf("%7f",&a[i]);
		            printf("x's exponent (x_exp):");
		            scanf("%7f",&b[i]);
		            printf("add: %4f * x ^ %4f\n",a[i],b[i]);
	            }
	            printf("\n  x0 \t \t x \t \t f(x0) \t \t f'(x0) \t \t iterasyon");
                while(MAX2>hata&&iterasyon<100){
		            x=x0-(fonksiyon(a, b, n, x0)/turev(a, b, n, x0));
					iterasyon++;
		            printf("\n %f \t %f \t %f \t %f \t \t",x0,x,fonksiyon(a, b, n, x0),turev(a, b, n, x0));
		            printf("%d ",iterasyon);
		            MAX2=x-x0;
		            if(MAX<0){
		                MAX2=MAX2*(-1);
	                }
                    x0=x;
	            }
	            printf("\nsonuc: %f",x);

				break;
		case 3:
			printf("\n\n\t\t\t\t\tN*N'LIK MATRISIN TERSI\n");
			
			    printf("matris boyutunu giriniz:");
	            scanf("%d",&n);
	            for(i=0;i<n;i++){
		           for(j=0;j<n;j++){
			          printf("[%d][%d]:",i,j);
			          scanf("%4f",&aa[i][j]);
		            }
		            printf("\n");
	            }
	            printf("\nmatris:\n");
	            for(i=0;i<n;i++){
		            for(j=0;j<n;j++){
			           printf("   %f  ",aa[i][j]);
		            }
		            printf("\n");
	            }
	            for(i=0;i<n;i++){
		            for(j=0;j<n;j++){
			            if(i==j)
			                bb[i][j]=1;
			            else
			                bb[i][j]=0;
			
		            }
	            }
	            for(i=0;i<n;i++){
	         	    d=aa[i][i];
	 	            for(j=0;j<n;j++){
			            aa[i][j]=aa[i][j]/d;
			            bb[i][j]=bb[i][j]/d;
		            }
		            for(xx=0;xx<n;xx++){
			            if(xx!=i){
				           k=aa[xx][i];
				           for(t=0;t<n;t++){
					            aa[xx][t]=aa[xx][t]-(aa[i][t]*k);
					            bb[xx][t]=bb[xx][t]-(bb[i][t]*k);
				           }
			            }
		            }
	            }
	            printf("\nmatrisin tersi: \n");
	            for(i=0;i<n;i++){
		            for(j=0;j<n;j++){
		                printf("%4f   ",bb[i][j]);
		            }
		            printf("\n");
	            }
				break;
		case 4:
			printf("\n\n\t\t\t\t\tGAUSS ELIMINASYON YONTEMI\n");
			
				printf("lineer denklem sistemi: N, A*X=C\n");
	            printf("matris boyutunu giriniz:");
	            scanf("%d",&n);
	            printf("A matrisini giriniz:\n");
	            for(i=0;i<n;i++){
		            for(j=0;j<n;j++){
			            printf("[%d][%d]:",i,j);
			            scanf("%f",&A[i][j]);
		            }
	            }
	            printf("\nA matrisi: \n");
	            for(i=0;i<n;i++){
		            for(j=0;j<n;j++){
			            printf("%3f",A[i][j]);
			            printf("  ");
	            	}
		            printf("\n");
	            }
	            printf("\nC matrisini giriniz:\n");
	            for(i=0;i<n;i++){
		            printf("[%d]:",i);
		            scanf("%f",&C[i][1]);
	            }
	            printf("\nC matrisi: \n");
	            for(i=0;i<n;i++){
		            printf("%3f",C[i][1]);
		            printf("\n");
	            }
	            printf("\n \n");
	
	            for(i=0;i<n;i++){
		            d=A[i][i];
		            for(j=0;j<n;j++){
			            A[i][j]=A[i][j]/d;
			        }
		            C[i][1]=C[i][1]/d;
		            for(xx=0;xx<n;xx++){
			            if(xx!=i){
				            k=A[xx][i];
				            for(t=0;t<n;t++){
					            A[xx][t]=A[xx][t]-(A[i][t]*k);
				            }
				            C[xx][1]=C[xx][1]-(C[i][1]*k);
			            }
	 	            }
	            }
	
	
	            printf("cevaplar matrisi(x):\n");
	            for(i=0;i<n;i++){
		            printf("%f",C[i][1]);
		            printf("\n");
	            }
	            printf("\n \n");
		        break;
		case 5:
			printf("\n\n\t\t\t\t\tGAUSS-SEIDEL YONTEMI\n");
			
			    printf("lineer denklem sistemi: N, A*X=C\n");
	            printf("matris boyutunu giriniz:");
	            scanf("%d",&n);
	            printf("\nA matrisini baskin matris seklinde giriniz:\n");
				for(i=0;i<n;i++){
		            for(j=0;j<n;j++){
			            printf("A[%d][%d]:",i,j);
			            scanf("%f",&A[i][j]);
		            }
	            }
	            printf("A matrisi: \n");
	            for(i=0;i<n;i++){
		            for(j=0;j<n;j++){
			            printf("%3f",A[i][j]);
			            printf("  ");
		            }
		            printf("\n");
	            }
	            printf("C matrisini giriniz:\n");
	            for(i=0;i<n;i++){
		            printf("C[%d][1]:",i);
		            scanf("%f",&C[i][1]);
	            }
	            printf("C matrisi:\n");
	            for(i=0;i<n;i++){
		            printf("%3f",C[i][1]);
		            printf("\n");
	            }
	            printf("\n \n");
	            printf("baslangic deger matrisini giriniz:\n");
	            for(i=0;i<n;i++){
		            printf("x0[%d]:",i);
		            scanf("%f",&x00[i]);
              	}
	            printf("baslangic deger matrisi:\n");
	            for(i=0;i<n;i++){
		            printf("%3f",x00[i]);
		            printf("\n");
	            }
	            printf("\n \n");
	            printf("iterasyon sayisini giriniz:");
                scanf("%d",&iterasyon);
                for(i=0;i<iterasyon;i++){
                    x00[0]=fonkx(A,C,x00,n);
                    x00[1]=fonky(A,C,x00,n);
                    x00[2]=fonkz(A,C,x00,n);
                    x00[3]=fonkk(A,C,x00,n);
                    printf("sonuc:   ");
                    for(j=0;j<n;j++){
	                    printf("%f3  ",x00[j]);
                    }
                    printf("\n");
                }                   
				break;
		case 6:
			printf("\n\n\t\t\t\t\tSAYISAL TUREV\n");
			
				printf("turevin hesaplanacagi x degerini giriniz:");
	            scanf("%f",&x);
	            printf("hesaplamada 2 nokta arasindaki fark:");
	            scanf("%f",&h);
                printf("polinom sayisini giriniz:");
	            scanf("%d",&n);
	            for(i=0;i<n;i++){
		            printf("x_coef * x ^ x_exp:\n");
		            printf("x's cofactor (x_coef):\n");
		            scanf("%4f",&a[i]);
		            printf("x's exponent (x_exp):\n");
		            scanf("%4f",&b[i]);
		            printf("add: %4f * x ^ %4f\n",a[i],b[i]);
	            }
	            printf(" \nILERI FARK , 1\n GERI FARK , 2\n MERKEZI FARK , 3 \n");
	            printf("bir sayi giriniz:");
	            scanf("%d",&sayi);
	            if(sayi==1){
	                printf("\n\n");
	                printf("ILERI FARK\n\n");
	                printf("  x \t \t \t h \t \t \t (f(x+h)-f(x))/h");
	                sonuc=(fonksiyon(a, b, n, x+h)-fonksiyon(a, b, n, x))/h;
	                printf("\n %f \t \t %f \t \t %f",x,h,sonuc);
	                printf("\n\n sonuc: %f",sonuc);
                }
	            else if(sayi==2){
	                printf("\n\n");
		            printf("GERI FARK\n\n");
	                printf("  x \t \t \t h \t \t \t (f(x)-f(x-h))/h");
	                sonuc=(fonksiyon(a, b, n, x)-fonksiyon(a, b, n, x-h))/h;
	                printf("\n %f \t \t %f \t \t %f",x,h,sonuc);
	                printf("\n\n sonuc: %f",sonuc);
	            }
                else if(sayi==3){
	                printf("\n\n");
		            printf("MERKEZI FARK\n\n");
	                printf("  x \t \t \t h \t \t \t (f(x+h)-f(x-h))/2h");
                    sonuc=(fonksiyon(a, b, n, x+h)-fonksiyon(a, b, n, x-h))/(2*h);
	                printf("\n %f \t \t %f \t \t %f",x,h,sonuc);
	                printf("\n\n sonuc: %f",sonuc);
                }
                else
                    printf("sonuc bulunamadi:");
			    break;
		case 7:
			printf("\n\n\t\t\t\t\tSIMPSON YONTEMI \n");
			
			    printf("kokun bulundugu araligi giriniz: [a,b]\n");
	            printf("baslangic degeri: ");
	            scanf("%f",&start);
	            printf("bitis degeri: ");
	            scanf("%f",&end);
                printf("araligin ayrilacagi parca sayisini giriniz:");
                scanf("%d",&kk);
	            printf("polinom sayisini giriniz:");
	            scanf("%d",&n);
	            for(i=0;i<n;i++){
		            printf("x_coef * x ^ x_exp:\n");
		            printf("x's cofactor (x_coef):\n");
		            scanf("%4f",&a[i]);
		            printf("x's exponent (x_exp):\n");
		            scanf("%4f",&b[i]);
		            printf("add: %4f * x ^ %4f\n",a[i],b[i]);
	            }
	            h=(end-start)/kk;
                h_yedek=h;
	            for(i=1;i<kk;i++){
		            c[i]=fonksiyon(a, b, n, start+h );
		            h=h+h_yedek;
		        }
	            alan=0;
	            printf("simpson 1/3: 1\n simpson 3/8: 2\n");
	            printf("bir sayi giriniz:");
	            scanf("%d",&sayi);
                if(sayi==1){
	                for(i=1;i<kk;i++){
	                    if(i%2==0){
		                    alan=alan+2*c[i];
		                }
	                    else{
	 	                    alan=alan+4*c[i];
	 	                }
	                }
	                c[0]=fonksiyon(a, b, n, start);
	                c[kk]=fonksiyon(a, b, n, end);
	                alan=alan+(c[0]+c[kk]);
	                alan=alan*h_yedek/3;
	                printf("\n\n sonuc: %f",alan);
                }
                else if(sayi==2){
	                h=((end-start)/3)/kk;
                    h_yedek=h;
                    ara=(end-start)/kk;
                    for(i=0;i<kk;i++){
                        alan=alan + ara*(fonksiyon(a, b, n, start)+fonksiyon(a, b, n, start+ara)+3*fonksiyon(a, b, n, start+h)+3*fonksiyon(a, b, n, start+h+h))/8;
                        start=start+ara;
                        end=end+ara;
                        printf("\n  %d.alan: %f",i,alan);
                    }
                }  
                else
                    printf("sonuc bulunamadi:");
			    break;
		case 8:
			printf("\n\n\t\t\t\t\tTRAPEZ YONTEMI\n");
			
				printf("kokun bulundugu araligi giriniz: [a,b]\n");
	            printf("baslangic degeri: ");
	            scanf("%f",&start);
	            printf("bitis degeri: ");
	            scanf("%f",&end);
                printf("araligin ayrilacagi parca sayisini giriniz:");
                scanf("%d",&kk);
	            printf("polinom sayisini giriniz:");
	            scanf("%d",&n);
	            for(i=0;i<n;i++){
		            printf("x_coef * x ^ x_exp:\n");
		            printf("x's cofactor (x_coef):\n");
		            scanf("%4f",&a[i]);
		            printf("x's exponent (x_exp):\n");
		            scanf("%4f",&b[i]);
		            printf("add: %4f * x ^ %4f\n",a[i],b[i]);
	            }
	            h=(end-start)/kk;
                h_yedek=h;
	            for(i=1;i<kk;i++){
		            c[i]=fonksiyon(a, b, n, start+h );
		            h=h+h_yedek;
		        }
	            alan=0;
                for(i=1;i<kk;i++){
		            alan=alan+c[i];
	            }
	            c[0]=fonksiyon(a, b, n, start);
	            c[kk]=fonksiyon(a, b, n, end);
             	alan=alan+(c[0]+c[kk])/2;
             	alan=alan*h_yedek;
             	printf("\n\n sonuc: %f",alan);
			    break;
		case 9:
			printf("\n\n\t\t\t\t\tGREGORY-NEWTON ENTERPOLASYONU\n");
			
			   	printf("girmek istediginiz nokta sayisini giriniz:");
	            scanf("%d",&n);
	            for(i=0;i<n;i++){
		            for(j=0;j<2;j++){
			            printf("nokta(%d,%d):",i,j);
			            scanf("%d",&mat[i][j]);
		            }
	            }
                for(j=2;j<n;j++){
  	                for(i=0;i<n-1;i++){
  		                mat[i][j]=mat[i+1][j-1]-mat[i][j-1];
	                }
                }
  
                printf("bulmak istediginiz degeri giriniz:");
                scanf("%f",&x);
                sonuc=newfonk(mat, n, x);
                printf("%f",sonuc);
             	 break;
		default:
			    printf("islem bulunamadi");
 	 	         break;
			
	}
	
	
	
	return 0;
}
